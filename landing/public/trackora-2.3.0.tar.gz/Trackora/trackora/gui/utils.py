"""Shared GUI utility functions."""

from __future__ import annotations

import os
import sys
from PySide6.QtGui import QIcon, QPixmap
from PySide6.QtCore import QSize

# Linux/GNOME icon theme candidate list
_ICON_THEME_MAP: dict[str, list[str]] = {
    "VS Code": ["vscode", "visual-studio-code", "com.visualstudio.code", "com.visualstudio.code.oss", "code-oss", "code"],
    "Obsidian": ["md.obsidian.Obsidian", "obsidian", "md.obsidian"],
    "Md.Obsidian": ["md.obsidian.Obsidian", "obsidian", "md.obsidian"],
    "Document Viewer": ["org.gnome.Papers", "document-viewer", "org.gnome.Papers.desktop", "evince"],
    "Org.Gnome.Papers": ["org.gnome.Papers", "document-viewer"],
    "Papers": ["org.gnome.Papers", "document-viewer"],
    "Chrome": ["google-chrome", "chromium"],
    "Chromium": ["chromium"],
    "Brave": ["brave-browser"],
    "Firefox": ["firefox"],
    "Spotify": ["spotify"],
    "Discord": ["discord"],
    "Slack": ["slack"],
    "Telegram": ["telegram-desktop", "telegram"],
    "Files": ["org.gnome.Nautilus", "system-file-manager"],
    "Console": ["org.gnome.Console", "utilities-terminal"],
    "Settings": ["org.gnome.Settings", "preferences-system"],
    "Kitty": ["kitty"],
    "Terminal": ["org.gnome.Console", "utilities-terminal", "gnome-terminal"],
    "GitHub Desktop": ["github-desktop"],
    "Cursor": ["co.anysphere.cursor", "cursor"],
}
_FALLBACK_ICON = "application-x-executable"

from typing import Callable
from collections import defaultdict
from PySide6.QtCore import QObject, QRunnable, QSize, QThreadPool, Signal

# In-memory cache for resolved icons to avoid heavy scans
_ICON_CACHE: dict[str, QPixmap] = {}
_MISSING_ICON_CACHE: set[str] = set()
_PENDING_ICON_CALLBACKS: dict[str, list[Callable[[QPixmap | None], None]]] = defaultdict(list)
_RESOLVING_ICONS: set[str] = set()


class _IconWorkerSignals(QObject):
    icon_loaded = Signal(str, int, object)  # app_name, size, QPixmap or None


_SIGNALS: _IconWorkerSignals | None = None


def _get_signals() -> _IconWorkerSignals:
    global _SIGNALS
    if _SIGNALS is None:
        _SIGNALS = _IconWorkerSignals()
        _SIGNALS.icon_loaded.connect(_on_icon_loaded_slot)
    return _SIGNALS


def _on_icon_loaded_slot(app_name: str, size: int, pixmap: QPixmap | None) -> None:
    cache_key = f"{app_name}_{size}"
    callbacks = _PENDING_ICON_CALLBACKS.pop(cache_key, [])
    for cb in callbacks:
        try:
            cb(pixmap)
        except Exception:
            pass


class _AsyncIconTask(QRunnable):
    def __init__(self, app_name: str, size: int):
        super().__init__()
        self.app_name = app_name
        self.size = size

    def run(self) -> None:
        try:
            pixmap = _resolve_app_icon_sync(self.app_name, self.size)
        except Exception:
            pixmap = None
        finally:
            _RESOLVING_ICONS.discard(f"{self.app_name}_{self.size}")
            try:
                _get_signals().icon_loaded.emit(self.app_name, self.size, pixmap)
            except Exception:
                pass


def _resolve_app_icon_sync(app_name: str, size: int) -> QPixmap | None:
    """Internal synchronous icon resolver."""
    cache_key = f"{app_name}_{size}"
    if cache_key in _ICON_CACHE:
        return _ICON_CACHE[cache_key]
    if cache_key in _MISSING_ICON_CACHE:
        return None

    pixmap = None

    # Trackora asset logo fallback (works across all platforms)
    if app_name.lower() in ("trackora", "trackora dashboard", "trackora-dashboard"):
        try:
            from trackora.utils.paths import get_asset_path
            logo_path = get_asset_path("trackora_logo.png")
            if logo_path.exists():
                icon = QIcon(str(logo_path))
                if not icon.isNull():
                    pixmap = icon.pixmap(size, size)
        except Exception:
            pass

    if pixmap is None:
        if app_name.lower() == "desktop":
            if sys.platform == "win32":
                try:
                    from PySide6.QtWidgets import QFileIconProvider
                    provider = QFileIconProvider()
                    icon = provider.icon(QFileIconProvider.IconType.Desktop)
                    if not icon.isNull():
                        pixmap = icon.pixmap(size, size)
                except Exception:
                    pass
            else:
                candidates = ["user-desktop", "desktop", "preferences-desktop-wallpaper", "preferences-desktop"]
                for name in candidates:
                    icon = QIcon.fromTheme(name)
                    if not icon.isNull():
                        pixmap = icon.pixmap(QSize(size, size))
                        break
        elif sys.platform == "win32":
            # Windows native executable icon extraction
            exe_path = _find_win32_exe_path(app_name)
            if exe_path:
                try:
                    uwp_icon = _find_uwp_png_icon(exe_path)
                    if uwp_icon and os.path.exists(uwp_icon):
                        icon = QIcon(uwp_icon)
                        if not icon.isNull():
                            pixmap = icon.pixmap(size, size)

                    if pixmap is None:
                        if exe_path.lower().endswith((".png", ".jpg", ".jpeg")):
                            icon = QIcon(exe_path)
                            if not icon.isNull():
                                pixmap = icon.pixmap(size, size)
                        else:
                            from PySide6.QtWidgets import QFileIconProvider
                            from PySide6.QtCore import QFileInfo
                            provider = QFileIconProvider()
                            icon = provider.icon(QFileInfo(exe_path))
                            if not icon.isNull():
                                pixmap = icon.pixmap(size, size)
                except Exception:
                    pass
        else:
            # Linux standard XDG desktop icon theme lookup
            candidates = list(_ICON_THEME_MAP.get(app_name, []))

            # Query Linux desktop entry index for Icon= field if present
            try:
                from trackora.utils.app_names import _get_linux_desktop_index
                dt_index = _get_linux_desktop_index()
                clean_app = app_name.lower().strip()
                if clean_app in dt_index:
                    dt_icon = dt_index[clean_app][1]
                    if dt_icon and dt_icon not in candidates:
                        candidates.insert(0, dt_icon)
                else:
                    for k, (_, dt_icon) in dt_index.items():
                        if (k.startswith(clean_app + ".") or k.endswith("." + clean_app) or clean_app in k.split(".")) and dt_icon:
                            if dt_icon not in candidates:
                                candidates.insert(0, dt_icon)
                            break
            except Exception:
                pass

            # Add generic fallback name variants
            for name_variant in [app_name, app_name.lower(), app_name.lower().replace(" ", "-")]:
                if name_variant not in candidates:
                    candidates.append(name_variant)

            for name in candidates:
                # Try exact name, lowercased name, and hyphenated name
                for test_name in (name, name.lower(), name.replace(" ", "-")):
                    icon = QIcon.fromTheme(test_name)
                    if not icon.isNull():
                        pixmap = icon.pixmap(QSize(size, size))
                        break
                if pixmap is not None:
                    break

    if pixmap is not None:
        _ICON_CACHE[cache_key] = pixmap
    else:
        _MISSING_ICON_CACHE.add(cache_key)

    return pixmap



def get_app_icon(
    app_name: str,
    size: int = 24,
    on_loaded: Callable[[QPixmap | None], None] | None = None,
) -> QPixmap | None:
    """Retrieve application icon.
    
    If on_loaded is provided and icon is not yet cached, it resolves the icon
    asynchronously in the background without blocking the UI thread (0ms latency).
    """
    cache_key = f"{app_name}_{size}"
    if cache_key in _ICON_CACHE:
        return _ICON_CACHE[cache_key]
    if cache_key in _MISSING_ICON_CACHE:
        return None

    if on_loaded is not None:
        _PENDING_ICON_CALLBACKS[cache_key].append(on_loaded)
        if cache_key not in _RESOLVING_ICONS:
            _RESOLVING_ICONS.add(cache_key)
            task = _AsyncIconTask(app_name, size)
            QThreadPool.globalInstance().start(task)
        return None

    # Fallback to synchronous resolution if no callback was passed
    return _resolve_app_icon_sync(app_name, size)


_WIN_APP_ALIASES: dict[str, list[str]] = {
    "vs code": ["code", "code.exe", "vscode", "visual studio code"],
    "vscode": ["code", "code.exe", "vs code"],
    "visual studio code": ["code", "code.exe", "vscode"],
    "code": ["code", "code.exe", "vscode", "vs code"],
    "chrome": ["chrome", "chrome.exe", "google chrome"],
    "firefox": ["firefox", "firefox.exe"],
    "brave": ["brave", "brave.exe", "brave-browser"],
    "spotify": ["spotify", "spotify.exe"],
    "discord": ["discord", "discord.exe"],
    "slack": ["slack", "slack.exe"],
    "telegram": ["telegram", "telegram.exe"],
    "whatsapp": ["whatsapp", "whatsapp.exe", "whatsapp.root", "whatsappdesktop"],
    "whatsapp.root": ["whatsapp.root", "whatsapp", "whatsapp.exe"],
    "whatsappdesktop": ["whatsappdesktop", "whatsapp", "whatsapp.exe"],
    "onenote": ["onenote", "onenoteim", "onenote.exe", "onenoteim.exe"],
    "settings": ["systemsettings", "systemsettings.exe", "settings"],
}

_START_MENU_SHORTCUT_INDEX: dict[str, str] | None = None
_EXE_SEARCH_CACHE: dict[str, str | None] = {}
_EXE_PATHS_JSON_CACHE: dict[str, str] = {}
_EXE_PATHS_JSON_MTIME: float = -1.0


def _get_start_menu_shortcuts() -> dict[str, str]:
    global _START_MENU_SHORTCUT_INDEX
    if _START_MENU_SHORTCUT_INDEX is not None:
        return _START_MENU_SHORTCUT_INDEX

    _START_MENU_SHORTCUT_INDEX = {}
    start_menu_dirs = [
        os.path.join(os.environ.get("APPDATA", ""), "Microsoft", "Windows", "Start Menu", "Programs"),
        os.path.join(os.environ.get("ALLUSERSPROFILE", ""), "Microsoft", "Windows", "Start Menu", "Programs"),
    ]
    for sm_dir in start_menu_dirs:
        if not os.path.exists(sm_dir):
            continue
        try:
            for root_dir, _, files in os.walk(sm_dir):
                for f in files:
                    if f.lower().endswith(".lnk"):
                        fname_lower = os.path.splitext(f.lower())[0]
                        if fname_lower not in _START_MENU_SHORTCUT_INDEX:
                            _START_MENU_SHORTCUT_INDEX[fname_lower] = os.path.join(root_dir, f)
        except Exception:
            pass
    return _START_MENU_SHORTCUT_INDEX


def _find_win32_exe_path(app_name: str) -> str | None:
    """Find Windows executable path for app_name via aliases, known paths, cache, registry, or Start Menu shortcuts."""
    if not app_name:
        return None

    app_lower = app_name.lower().strip()
    if app_lower in _EXE_SEARCH_CACHE:
        return _EXE_SEARCH_CACHE[app_lower]

    # 0. Check direct known installation paths for common desktop apps
    known_paths = {
        "vs code": [
            os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs", "Microsoft VS Code", "Code.exe"),
            os.path.join(os.environ.get("ProgramFiles", ""), "Microsoft VS Code", "Code.exe"),
            os.path.join(os.environ.get("ProgramFiles(x86)", ""), "Microsoft VS Code", "Code.exe"),
        ],
        "vscode": [
            os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs", "Microsoft VS Code", "Code.exe"),
            os.path.join(os.environ.get("ProgramFiles", ""), "Microsoft VS Code", "Code.exe"),
        ],
        "visual studio code": [
            os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs", "Microsoft VS Code", "Code.exe"),
            os.path.join(os.environ.get("ProgramFiles", ""), "Microsoft VS Code", "Code.exe"),
        ],
        "chrome": [
            os.path.join(os.environ.get("ProgramFiles", ""), "Google", "Chrome", "Application", "chrome.exe"),
            os.path.join(os.environ.get("ProgramFiles(x86)", ""), "Google", "Chrome", "Application", "chrome.exe"),
        ],
        "edge": [
            os.path.join(os.environ.get("ProgramFiles(x86)", ""), "Microsoft", "Edge", "Application", "msedge.exe"),
            os.path.join(os.environ.get("ProgramFiles", ""), "Microsoft", "Edge", "Application", "msedge.exe"),
        ],
        "whatsapp": [
            os.path.join(os.environ.get("LOCALAPPDATA", ""), "Microsoft", "WindowsApps", "WhatsApp.exe"),
            os.path.join(os.environ.get("LOCALAPPDATA", ""), "WhatsApp", "WhatsApp.exe"),
            os.path.join(os.environ.get("ProgramFiles", ""), "WindowsApps", "WhatsApp.exe"),
            os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs", "WhatsApp", "WhatsApp.exe"),
        ],
        "whatsapp.root": [
            os.path.join(os.environ.get("LOCALAPPDATA", ""), "Microsoft", "WindowsApps", "WhatsApp.exe"),
            os.path.join(os.environ.get("LOCALAPPDATA", ""), "WhatsApp", "WhatsApp.exe"),
            os.path.join(os.environ.get("ProgramFiles", ""), "WindowsApps", "WhatsApp.exe"),
        ],
        "onenote": [
            os.path.join(os.environ.get("ProgramFiles", ""), "Microsoft Office", "root", "Office16", "ONENOTE.EXE"),
            os.path.join(os.environ.get("ProgramFiles(x86)", ""), "Microsoft Office", "root", "Office16", "ONENOTE.EXE"),
        ],
        "settings": [
            os.path.join(os.environ.get("windir", "C:\\Windows"), "ImmersiveControlPanel", "SystemSettings.exe"),
        ],
        "spotify": [
            os.path.join(os.environ.get("APPDATA", ""), "Spotify", "Spotify.exe"),
            os.path.join(os.environ.get("LOCALAPPDATA", ""), "Microsoft", "WindowsApps", "Spotify.exe"),
        ],
    }

    if app_lower in known_paths:
        for p in known_paths[app_lower]:
            if p and os.path.exists(p):
                _EXE_SEARCH_CACHE[app_lower] = p
                return p

    # Build search variants including aliases
    search_names = {app_lower, app_lower.replace(" ", "-"), app_lower.replace(" ", "_")}
    if app_lower in _WIN_APP_ALIASES:
        search_names.update(_WIN_APP_ALIASES[app_lower])

    # 1. Check daemon's JSON path cache (memory cached)
    try:
        from trackora.utils.paths import trackora_data_dir
        import json
        global _EXE_PATHS_JSON_MTIME, _EXE_PATHS_JSON_CACHE
        cache_file = trackora_data_dir() / "exe_paths.json"
        if cache_file.exists():
            mtime = cache_file.stat().st_mtime
            if mtime != _EXE_PATHS_JSON_MTIME:
                _EXE_PATHS_JSON_CACHE = json.loads(cache_file.read_text(encoding="utf-8"))
                _EXE_PATHS_JSON_MTIME = mtime
            for key, val in _EXE_PATHS_JSON_CACHE.items():
                if key.lower() in search_names:
                    if val and os.path.exists(val):
                        if "WindowsApps" in val or "Packages" in val:
                            uwp_icon = _find_uwp_png_icon(val)
                            if uwp_icon:
                                _EXE_SEARCH_CACHE[app_lower] = uwp_icon
                                return uwp_icon
                        _EXE_SEARCH_CACHE[app_lower] = val
                        return val
    except Exception:
        pass

    # 2. Hardcoded system apps fallbacks
    sys_fallbacks = {
        "explorer": os.path.join(os.environ.get("windir", "C:\\Windows"), "explorer.exe"),
        "taskmgr": os.path.join(os.environ.get("windir", "C:\\Windows\\System32"), "taskmgr.exe"),
        "cmd": os.path.join(os.environ.get("windir", "C:\\Windows\\System32"), "cmd.exe"),
        "powershell": os.path.join(os.environ.get("windir", "C:\\Windows\\System32\\WindowsPowerShell\\v1.0"), "powershell.exe"),
    }
    if app_lower in sys_fallbacks:
        path = sys_fallbacks[app_lower]
        if os.path.exists(path):
            _EXE_SEARCH_CACHE[app_lower] = path
            return path

    # 3. Registry App Paths
    try:
        import winreg
        for sname in search_names:
            for name in (sname, f"{sname}.exe"):
                for root in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE):
                    key_path = f"Software\\Microsoft\\Windows\\CurrentVersion\\App Paths\\{name}"
                    try:
                        with winreg.OpenKey(root, key_path) as key:
                            val, _ = winreg.QueryValueEx(key, "")
                            if val and os.path.exists(val):
                                _EXE_SEARCH_CACHE[app_lower] = val
                                return val
                    except OSError:
                        continue
    except Exception:
        pass

    # 4. Start Menu shortcuts scan using single-pass index
    try:
        sm_shortcuts = _get_start_menu_shortcuts()
        for sname in search_names:
            if sname in sm_shortcuts:
                _EXE_SEARCH_CACHE[app_lower] = sm_shortcuts[sname]
                return sm_shortcuts[sname]
        for key, path in sm_shortcuts.items():
            if any(sname in key for sname in search_names if len(sname) >= 3):
                _EXE_SEARCH_CACHE[app_lower] = path
                return path
    except Exception:
        pass

    _EXE_SEARCH_CACHE[app_lower] = None
    return None


def _find_uwp_png_icon(exe_path: str) -> str | None:
    """Scan the UWP package directory for a high-resolution logo PNG or ICO."""
    if not exe_path:
        return None
    try:
        app_dir = os.path.dirname(exe_path)
        search_dirs = [app_dir]
        parent_dir = os.path.dirname(app_dir)
        if "WindowsApps" in parent_dir or "Packages" in parent_dir:
            search_dirs.append(parent_dir)

        sub_names = ["assets", "images", "img", "icons", "res", "resources", "notepad"]
        for sd in list(search_dirs):
            for sub in sub_names:
                p = os.path.join(sd, sub)
                if os.path.exists(p) and p not in search_dirs:
                    search_dirs.append(p)

        candidates = []
        for s_dir in search_dirs:
            if not os.path.exists(s_dir):
                continue
            try:
                for file in os.listdir(s_dir):
                    f_lower = file.lower()
                    if f_lower.endswith((".png", ".ico")):
                        full_p = os.path.join(s_dir, file)
                        candidates.append((file, full_p))
            except Exception:
                pass

        if not candidates:
            return None

        priority_keywords = [
            "square44x44logo", "square150x150logo", "storelogo", "titleicon",
            "applist", "smalllogo", "graphicslogo", "logo", "icon"
        ]

        scored = []
        for name, path in candidates:
            n_lower = name.lower()
            if "bg" in n_lower or "background" in n_lower or "banner" in n_lower or "hero" in n_lower:
                continue
            score = 0
            for idx, kw in enumerate(priority_keywords):
                if kw in n_lower:
                    score += (len(priority_keywords) - idx) * 10
                    break
            if "scale-200" in n_lower or "targetsize" in n_lower:
                score += 5
            elif "scale-100" in n_lower:
                score += 2
            if score > 0:
                scored.append((score, path))

        if scored:
            scored.sort(key=lambda x: x[0], reverse=True)
            return scored[0][1]

        return candidates[0][1]
    except Exception:
        pass
    return None
