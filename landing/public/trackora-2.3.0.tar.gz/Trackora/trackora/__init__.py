"""Trackora: GNOME Shell extension writes focus JSON; Python persists sessions."""

__version__ = "2.3.0"
