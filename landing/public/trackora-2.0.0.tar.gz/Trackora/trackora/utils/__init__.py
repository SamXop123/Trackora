"""Utility helpers for Trackora."""
