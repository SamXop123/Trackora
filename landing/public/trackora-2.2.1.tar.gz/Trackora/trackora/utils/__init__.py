"""Utility helpers for Trackora."""
