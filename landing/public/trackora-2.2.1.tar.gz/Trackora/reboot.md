
Close service: systemctl --user stop trackora.service

Start service: systemctl --user start trackora.service

Enable service: systemctl --user enable trackora.service

Disable service: systemctl --user disable trackora.service

Restart service: systemctl --user restart trackora.service

Status: systemctl --user status trackora.service

// Custom DB:
./generate_demo_db.py
